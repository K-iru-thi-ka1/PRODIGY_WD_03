# Tic-Tac-Toe
This is a simple Tic-Tac-Toe game made using JS, HTML &amp; CSS


![Alt text](https://github.com/souvik2k21/Tic-Tac-Toe-Game/blob/main/Screenshot%202023-11-03%20201101.png)https://github.com/souvik2k21/Tic-Tac-Toe-Game/blob/main/Screenshot%202023-11-03%20201101.png)
